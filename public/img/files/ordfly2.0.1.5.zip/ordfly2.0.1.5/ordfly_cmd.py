import rhinoscriptsyntax as rs

__commandname__ = "ordfly"
# RunCommand is the called when the user enters the command name in Rhino.
# The command name is defined by the filname minus "_cmd.py"
def RunCommand( is_interactive ):
    print("hello, this is wangenius.")
    obj = rs.GetObject("Select a curve which start point has different height with the end point",rs.filter.curve)
    if(obj):
        points = rs.CurvePoints(obj)
        step = (points[len(points) - 1].Z - points[0].Z) / (len(points) - 1)
        for i in range(0,len(points)-1,1):
            points[i].Z = step * i
        rs.AddCurve(points)
    else:
        print("cancel the commend")
RunCommand(True)